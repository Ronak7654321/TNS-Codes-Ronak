package com.tns.fooddeliverysystem.services;

public class OrderService {
    public void placeOrder() {
        System.out.println("Placing an order...");
    }
}
