const players = document.querySelectorAll('.player_name');
const totalScores = [0, 0, 0, 0];
const currentScores = [0, 0, 0, 0];
const rounds = [0, 0, 0, 0];
let activePlayer = 0;
let gamePlaying = true;
const diceImage = document.querySelector('.dice_image');
const rollBtn = document.querySelector('.roll');
const holdBtn = document.querySelector('.hold');
const resetBtn = document.querySelector('.reset');
const winnerName = document.getElementById('winner_name');
const playerNames = ['Player 1', 'Player 2', 'Player 3', 'Player 4'];

function switchPlayer() {
  document.querySelector(`.player_${activePlayer}`).classList.remove('active');
  currentScores[activePlayer] = 0;
  document.getElementById(`current_score_${activePlayer}`).textContent = 0;
  
  // Check if current player has completed 5 rounds
  if (rounds[activePlayer] >= 5) {
    activePlayer = (activePlayer + 1) % 4;
  } else {
    rounds[activePlayer]++;
    document.getElementById(`round_count_${activePlayer}`).textContent = `Round: ${rounds[activePlayer]}`;
  }
  
  // Check if all players have completed their 5 rounds
  if (rounds.every(round => round >= 5)) {
    determineWinner();
  } else {
    activePlayer = (activePlayer + 1) % 4;
    document.querySelector(`.player_${activePlayer}`).classList.add('active');
  }
}

function rollDice() {
  if (gamePlaying && rounds[activePlayer] < 5) {
    const dice = Math.floor(Math.random() * 6) + 1;
    diceImage.src = `dice-${dice}.png`;

    if (dice !== 1) {
      currentScores[activePlayer] += dice;
      document.getElementById(`current_score_${activePlayer}`).textContent = currentScores[activePlayer];
    } else {
      switchPlayer();
    }
  }
}

function hold() {
  if (gamePlaying && rounds[activePlayer] < 5) {
    totalScores[activePlayer] += currentScores[activePlayer];
    document.getElementById(`total_score_${activePlayer}`).textContent = totalScores[activePlayer];
    
    switchPlayer();
  }
}

function determineWinner() {
  let maxScore = Math.max(...totalScores);
  let winnerIndex = totalScores.indexOf(maxScore);
  document.querySelector(`.player_${winnerIndex}`).classList.add('winner');
  gamePlaying = false;
  winnerName.textContent = `${playerNames[winnerIndex]} Wins!! 🎉`;
}

function resetGame() {
  totalScores.fill(0);
  currentScores.fill(0);
  rounds.fill(0);
  gamePlaying = true;

  for (let i = 0; i < 4; i++) {
    document.getElementById(`total_score_${i}`).textContent = 0;
    document.getElementById(`current_score_${i}`).textContent = 0;
    document.getElementById(`round_count_${i}`).textContent = 'Round: 0';
    document.querySelector(`.player_${i}`).classList.remove('winner', 'active');
  }

  activePlayer = 0;
  document.querySelector(`.player_0`).classList.add('active');
  diceImage.src = `dice-5.png`; // Reset dice image
  winnerName.textContent = ''; // Clear winner name
}

rollBtn.addEventListener('click', rollDice);
holdBtn.addEventListener('click', hold);
resetBtn.addEventListener('click', resetGame);

players.forEach((player, index) => {
  const name = prompt(`Enter name for ${playerNames[index]}:`) || playerNames[index];
  playerNames[index] = name;
  player.textContent = name;
});
